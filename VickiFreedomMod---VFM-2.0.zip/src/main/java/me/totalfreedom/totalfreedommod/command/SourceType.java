package me.totalfreedom.totalfreedommod.command;

public enum SourceType
{

    ONLY_IN_GAME, ONLY_CONSOLE, BOTH;
}
