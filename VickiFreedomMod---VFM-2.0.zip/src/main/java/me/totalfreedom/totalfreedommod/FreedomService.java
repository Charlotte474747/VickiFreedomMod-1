package me.totalfreedom.totalfreedommod;

import net.pravian.aero.component.service.AbstractService;

public abstract class FreedomService extends AbstractService<TotalFreedomMod>
{

    public FreedomService(TotalFreedomMod plugin)
    {
        super(plugin);
    }

}
